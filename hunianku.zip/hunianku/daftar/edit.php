<?php
require 'functions.php';

//ambil data di URL
$id = $_GET["id"];

//query data berdasarkan id
$user = query("SELECT * FROM list_user WHERE id = $id") [0];

//cek apakah tombol add data sudah ditekan atau belum
if (isset ($_POST["submit"]) ) {

    //cek apakah data berhasil diubah atau tidak
    if (edit ($_POST) > 0 ) {
        echo "
            <script>
                alert ('Data Berhasil Diubah !');
                document.location.href = 'index.php';
            </script>
        ";
    }
    else {
        echo "
            <script>
                alert ('Data Gagal Diubah !');
                document.location.href = 'index.php';
            </script>
        ";
    }
}
?>

<!DOCTYPE html>
<html>
    <head>
        <title> User Hunianku </title>
    </head>
<body>

<h2><center> Edit User Hunianku </h2>

<form action="" method="POST">
    <input type="hidden" name="id" value="<?=$user["id"]?>">"
    <ul>
        <li>
            <label for="nik"> No. NIK : </label>
            <input type="text" name="nik" id="nik" required value="<?= $user["nik"] ?>">
        </li>
        <li>
            <label for="namaL"> Nama Lengkap : </label>
            <input type="text" name="namaL" id="namaL" required value="<?= $user["namaL"] ?>">
        </li>
        <li>
            <label for="namaP"> Nama Panggilan : </label>
            <input type="text" name="namaP" id="namaP" value="<?= $user["namaP"] ?>">
        </li>
        <li>
            <label for="usia"> Usia : </label>
            <input type="text" name="usia" id="usia" required value="<?= $user["usia"] ?>">
        </li>
        <li>
            <label for="tempat_lahir"> Tempat Lahir : </label>
            <input type="text" name="tempat_lahir" id="tempat_lahir" required value="<?= $user["tempat_lahir"] ?>">
        </li>
        <li>
            <label for="no_telp"> No. Telp : </label>
            <input type="text" name="no_telp" id="no_telp" required value="<?= $user["no_telp"] ?>">
        </li>
        <li>
            <label for="negara"> Kewarganegaraan : </label>
            <input type="text" name="negara" id="negara" required value="<?= $user["negara"] ?>">
        </li>
        <li>
            <label for="email"> Email : </label>
            <input type="text" name="email" id="email" required value="<?= $user["email"] ?>">
        </li>
        <li>
            <label for="alamat"> Alamat : </label>
            <input type="text" name="alamat" id="alamat" required value="<?= $user["alamat"] ?>">
        </li>
        <li>
            <label for="foto"> Foto Diri : </label>
            <input type="file" name="foto" id="foto" value="<?= $user["foto"] ?>">
        </li>
        
    </ul>
    <button type="submit" name="submit"> Edit Data </button>
    
</form>

</body>
</html>