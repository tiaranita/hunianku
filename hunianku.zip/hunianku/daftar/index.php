

<!DOCTYPE html>
<html>
    <head>
        <title> User Hunianku </title>
        <link rel="stylesheet" href="style.css">
    </head>
<body>
<br>
<h1><center> New User Hunianku </h1>

<br><br>

<font size = 4> 
<h4>  &nbsp &nbsp &nbsp Yuk Daftarkan Dirimu, Sekarang Juga!</h4>

<form action="" method="POST" enctype="multipart/form-data">
    <ul>
        <li>
            <label for="nik"> No. NIK &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp: </label>
            <input type="text" name="nik" id="nik" placeholder=" 15 - 16 Digit Angka" required>
        </li>
        <li>
            <label for="namaL"> Nama Lengkap &nbsp &nbsp : </label>
            <input type="text" name="namaL" id="namaL" required>
        </li>
        <li>
            <label for="namaP"> Nama Panggilan &nbsp : </label>
            <input type="text" name="namaP" id="namaP">
        </li>
        <li>
            <label for="usia"> Usia &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp: </label>
            <input type="text" name="usia" id="usia" placeholder=" 2 Digit Angka" required>
        </li>
        <li>
            <label for="tempat_lahir"> Tempat Lahir &nbsp &nbsp &nbsp &nbsp: </label>
            <input type="text" name="tempat_lahir" id="tempat_lahir" required>
        </li>
        <li>
            <label for="no_telp"> No. Telepon &nbsp &nbsp &nbsp &nbsp &nbsp: </label>
            <input type="text" name="no_telp" id="no_telp" placeholder=" Contoh : 081234567890" required>
        </li>
        <li>
            <label for="negara"> Kewarganegaraan : </label>
            <input type="text" name="negara" id="negara" required>
        </li>
        <li>
            <label for="email"> Email &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp: </label>
            <input type="text" name="email" id="email" placeholder=" example@gmail.com" required>
        </li>
        <li>
            <label for="alamat"> Alamat &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp: </label>
            <input type="text" name="alamat" id="alamat" required>
        </li>
        <li>
            <label for="foto"> Foto Diri &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp : </label>
            <input type="file" name="foto" id="foto">
        </li>
        
    </ul> 
    <center><button type="submit" name="submit"> Register </button>
    
</form>


</body>
</html>
