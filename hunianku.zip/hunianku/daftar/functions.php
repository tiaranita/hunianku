<?php 
//koneksi ke database
$konek = mysqli_connect("localhost", "root", "", "hunianku");

function query($query) {
    global $konek;
    $hasil = mysqli_query($konek, $query);
    $rows = [];
    while ($row = mysqli_fetch_assoc($hasil))  {
        $rows[] = $row;
    }
    return $rows;
}

function tambah($data) {
    global $konek;

    $nik = htmlspecialchars($data["nik"]);
    $namaL = htmlspecialchars($data["namaL"]);
    $namaP = htmlspecialchars($data["namaP"]);
    $usia = htmlspecialchars($data["usia"]);
    $tempat_lahir = htmlspecialchars($data["tempat_lahir"]);
    $no_telp = htmlspecialchars($data["no_telp"]);
    $negara = htmlspecialchars($data["negara"]);
    $email = htmlspecialchars($data["email"]);
    $alamat = htmlspecialchars($data["alamat"]);

    //upload foto
    $foto = upload();

    if ( !$foto ) {
        return false;
    }

    //query insert data
    $add = "INSERT INTO list_user
                VALUES
             ('','$nik','$namaL','$namaP','$usia','$tempat_lahir',
             '$no_telp','$negara','$email','$alamat','$foto')
           ";

    mysqli_query($konek, $add);

    return mysqli_affected_rows($konek);
}

function upload() {
  
    $namaFile = $_FILES['foto']['name'];
    $ukuranFile = $_FILES['foto']['size'];
    $error = $_FILES['foto']['error'];
    $tmpName = $_FILES['foto']['tmp_name'];

    //cek apakah anda foto yang diunggah
    if ($error === 4) {
        echo "
        <script>
            alert('Pilih Foto Terlebih Dahulu !');
        </script>";

        return false;
    }

    //cek apakah yang diunggah gambar atau bukan
    $ekstensiFotoValid = ['jpg','jpeg','png'];
    $ekstensiFoto = explode('.', $namaFile);
    $ekstensiFoto = strtolower (end($ekstensiFoto) );    

    if ( !in_array($ekstensiFoto, $ekstensiFotoValid) ) {
        echo "
        <script>
            alert('Pilih File Gambar yang Sesuai !');
        </script>";

        return false;
    }

    //cek jika ukurannya terlalu besar
    if ($ukuranFile > 1000000) {
        echo "
        <script>
            alert('Ukuran File Terlalu Besar !');
        </script>";
    }

    //lolos pengecekan, foto siap di upload
    move_uploaded_file($tmpName, 'img/' . $namaFile);

    return $namaFile;
}

function hapus($id) {
    global $konek;
    mysqli_query($konek, "DELETE FROM list_user WHERE id = $id"); 
    return mysqli_affected_rows($konek);
}

function edit($data) {
    global $konek;

    $id = $data["id"];
    $nik = htmlspecialchars($data["nik"]);
    $namaL = htmlspecialchars($data["namaL"]);
    $namaP = htmlspecialchars($data["namaP"]);
    $usia = htmlspecialchars($data["usia"]);
    $tempat_lahir = htmlspecialchars($data["tempat_lahir"]);
    $no_telp = htmlspecialchars($data["no_telp"]);
    $negara = htmlspecialchars($data["negara"]);
    $email = htmlspecialchars($data["email"]);
    $alamat = htmlspecialchars($data["alamat"]);
    $foto = htmlspecialchars($data["foto"]);

    //query edit data
    $add = "UPDATE list_user SET 
                nik = '$nik',
                namaL = '$namaL',
                namaP = '$namaP',
                usia = '$usia',
                tempat_lahir = '$tempat_lahir',
                no_telp = '$no_telp',
                negara = '$negara',
                email = '$email',
                alamat = '$alamat',
                foto = '$foto'

                WHERE id = $id
           ";

    mysqli_query($konek, $add);

    return mysqli_affected_rows($konek);

}

function search($keyword) {
    $query = "SELECT * FROM list_user 
                WHERE
                namaL LIKE '%$keyword%' OR
                namaP LIKE '%$keyword%' OR
                nik LIKE '%$keyword%' OR
                email LIKE '%$keyword%' OR
                no_telp LIKE '%$keyword%' OR
                negara LIKE '%$keyword%' OR
                alamat LIKE '%$keyword%'
                ";

    return query($query);
}

?>